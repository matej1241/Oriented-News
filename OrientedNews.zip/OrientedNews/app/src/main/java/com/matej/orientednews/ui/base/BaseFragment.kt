package com.matej.orientednews.ui.base

class BaseFragment: Fragment() {
}